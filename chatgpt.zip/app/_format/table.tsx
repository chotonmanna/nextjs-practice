import { memo } from "react";

export default memo(function AnswerAsTable({
  msgText,
}: Readonly<{ msgText: string }>) {
  const msgTextArr = msgText.split("|\n|");
  const data: { key: string; value: string }[] = msgTextArr
    .filter((row, i) => i > 0 && row.includes("|"))
    .map((row) => {
      const rowAsArr = row.split("|");
      return { key: rowAsArr[0], value: rowAsArr[1] };
    });

  return (
    <>
      <h1 dangerouslySetInnerHTML={{ __html: msgTextArr[0] }}></h1>
      <table>
        <tbody>
          {data.map((obj, i) => (
            <tr key={i}>
              <th>{obj.key.trim().replaceAll('**', '')}</th>
              <td>{obj.value.trim()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
});
