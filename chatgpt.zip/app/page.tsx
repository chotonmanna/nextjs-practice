"use client";

import { FormEvent, useEffect, useRef, useState } from "react";
import MsgBox, { MsgModel } from "./_components/msg-box";
import { useSearchParams } from "next/navigation";

import { getAnswerByQuestion } from "./_service/api";
import UserDetails from "./_components/user-details";

const defaultQuestion = "Welcome to our Policy Buddy. Here is your basic policy details.";

export default function Home() {
  const [msgText, setMsgText] = useState("");
  const [isFormDisabled, setIsFormDisabled] = useState(false);
  const [chatList, setChatList] = useState<MsgModel[]>([]);
  const divRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const searchParams = useSearchParams();
  const [policyNumber, setPolicyNumber] = useState<string>('');

  useEffect(() => {
    handleOnTriggerAnswer(defaultQuestion);
  }, []);

  useEffect(() => {
    if (!isFormDisabled) {
      inputRef.current?.focus();
    }
  }, [isFormDisabled]);

  useEffect(() => {
    divRef?.current?.scrollTo({
      top: divRef?.current?.scrollTop + 1000,
      behavior: "smooth",
    });
  }, [chatList[chatList.length - 1]?.msgText]);

  const handleOnSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    handleOnTriggerAnswer(msgText);
    setMsgText("");
  };

  const handleOnTriggerAnswer = (msgText: string) => {
    setIsFormDisabled(true);
    let question = msgText;
    if (chatList.length === 0) {
      question = 'Describe the basic policy details in format like below? Policy Holder Name Policy Coverage, Policy Start Date, Policy End Date, Premium Amount, Discount Amount';
    }
    setChatList((list) => [
      ...list,
      { msgText, type: "Q" },
      { msgText: "", type: "A", status: "0" },
    ]);
    getAnswerByQuestion(question, searchParams.get("encryptedString") as string).then((msgText) => {
      setChatList((list) => {
        const lastIndex = list.length - 1;
        list[lastIndex] = { ...list[lastIndex], msgText, status: "2" };
        return list;
      });
      setIsFormDisabled(false);
    });
  };

  return searchParams.get("encryptedString") ? (
    <div className="container">
      <UserDetails setPolicyNumber={setPolicyNumber} encryptedString={searchParams.get("encryptedString") as string} />
      <section className="msger">
        <header className="msger-header">
          <div className="msger-header-title">
            KNOW YOUR POLICY : {policyNumber}
          </div>
          <div className="msger-header-options">
            <span>
              <i className="fas fa-cog"></i>
            </span>
          </div>
        </header>

        <main className="msger-chat" ref={divRef}>
          {chatList.map((data, i) => (
            <MsgBox key={i} data={data} />
          ))}
        </main>

        <form className="msger-inputarea" onSubmit={handleOnSubmit}>
          <input
            required
            disabled={isFormDisabled}
            type="text"
            className="msger-input"
            placeholder="Enter your message..."
            name="msgText"
            value={msgText}
            ref={inputRef}
            onChange={(e) => setMsgText(e.target.value)}
          />
          <button
            disabled={isFormDisabled}
            type="submit"
            className="msger-send-btn"
          >
            Send
          </button>
        </form>
      </section>
    </div>
  ) : (
    <h2>No Policy Available</h2>
  );
}
