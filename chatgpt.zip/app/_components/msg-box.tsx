import { memo } from "react";
import AnswerAsList from "../_format/list";
import AnswerAsTable from "../_format/table";

export interface MsgModel {
  type: "Q" | "A";
  msgText: string;
  status?: "0" | "1" | "2"; // 0 = Pending, 1 = Failed, 2 = Success
}
export default memo(function MsgBox({ data }: Readonly<{ data: MsgModel }>) {
  const dir = data.type === "Q" ? "left" : "right";

  const getAnswerFormat = (msgText: string) => {
    if (msgText.includes("table format") && msgText.includes("|\n| ")) {
      return <AnswerAsTable msgText={msgText} />;
    } else if (msgText.includes("\n* ")) {
      return <AnswerAsList msgText={msgText} />;
    } else {
      return <div dangerouslySetInnerHTML={{ __html: msgText }}></div>;
    }
  };

  return (
    <div className={`msg ${dir}-msg`}>
      <div className={`msg-img msg-img-${data.type.toLowerCase()}`}>
        {data.type}
      </div>

      <div className="msg-bubble">
        <div className="msg-info">
          <div
            className={`msg-info-name msg-info-name-${data.type.toLowerCase()}`}
          >
            {data.type === "Q" ? "Question" : "Answer"}
          </div>
        </div>
        {data.type === "Q" && <div className="msg-text" dangerouslySetInnerHTML={{ __html: data.msgText }}></div>}
        {data.type === "A" && (
          <div className="msg-text">
            {data.status === "0" && "........."}
            {data.status === "2" && getAnswerFormat(data.msgText)}
          </div>
        )}
      </div>
    </div>
  );
});
