import Image from "next/image";
import { Dispatch, SetStateAction, memo, useEffect, useState } from "react";
import { UserResponseType, getUserDetails } from "../_service/api";

export default memo(function UserDetails({encryptedString, setPolicyNumber}: {
  encryptedString: string;
  setPolicyNumber: Dispatch<SetStateAction<string>>
}) {
  const [userInfo, setUserInfo] = useState<UserResponseType | null>(null);

  useEffect(() => {
    getUserDetails(encryptedString).then((resp) => {
      if (resp) {
        setPolicyNumber(resp.policyNumber);
        setUserInfo(resp);
      }
    });
  }, []);

  return (
    <div className="user-details">
      <Image src="/images/axa-logo.jpg" width={75} height={75} alt="logo" />
      <h2>Policyholder Information</h2>
      {userInfo && (
        <table className="user-table">
          <tbody>
            <tr>
              <th>Policy Number</th>
              <td>{userInfo.policyNumber}</td>
            </tr>
            <tr>
              <th>Customer Name</th>
              <td>{`${userInfo.firstName} ${userInfo.lastName}`}</td>
            </tr>
            <tr>
              <th>Date of birth</th>
              <td>{userInfo.dob}</td>
            </tr>
            {/* <tr>
              <th>Policy duration</th>
              <td>{userInfo.policyDuration}</td>
            </tr>
            <tr>
              <th>Policy terms</th>
              <td>{userInfo.policyTerms}</td>
            </tr>
            <tr>
              <th>Premium Amount</th>
              <td>{userInfo.premiumAmount}</td>
            </tr>
            <tr>
              <th>Next Premium Date</th>
              <td>{userInfo.nextPremiumDate}</td>
            </tr> */}
            <tr>
              <th>Address</th>
              <td>{userInfo.address}</td>
            </tr>
            {/* <tr>
              <th>Nominee</th>
              <td>{userInfo.nominee}</td>
            </tr> */}
          </tbody>
        </table>
      )}
    </div>
  );
});
