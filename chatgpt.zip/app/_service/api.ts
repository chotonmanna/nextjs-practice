import axios from "axios";

interface AnswerResponseType {
  answer: string;
}

export interface UserResponseType {
  policyNumber: string;
  firstName: string;
  lastName: string;
  dob: string;
  policyDuration: string;
  policyTerms: string;
  premiumAmount: number;
  nextPremiumDate: string;
  address: string;
  nominee: string;
}

export const getUserDetails = (encryptedString: string): Promise<UserResponseType | null> => {
  return axios
    .get<UserResponseType>(
      `http://localhost:8080/policybuddy?encryptedString=${encryptedString}`
    )
    .then((resp) => {
      return Promise.resolve(resp.data);
    })
    .catch(() => Promise.resolve(null));
};

export const getAnswerByQuestion = (
  question: string,
  encryptedString: string
): Promise<string> => {
  return axios
    .post<AnswerResponseType>(
      `http://localhost:8080/policybuddy?encryptedString=${encryptedString}`,
      { questions: [question] }
    )
    .then((resp) => {
      return Promise.resolve(resp.data.answer);
    })
    .catch(() => Promise.resolve("Unable to get answer"));
};
