"use client";

//import { Container, Row, Col, Button, Card, ProgressBar } from "react-bootstrap";

export default function Home() {
  return (
    <h2>App Home Page</h2>
    // <Container>
    //   <Row>
    //     <Col md="12">
    //       <Row>
    //         <Col className="p-0">
    //           1. Votre activité
    //           <ProgressBar now={60} />
    //         </Col>
    //         <Col className="p-0">2. Vos besoins <ProgressBar now={0} /></Col>
    //         <Col className="p-0">3. Vos données <ProgressBar now={0} /></Col>
    //         <Col className="p-0">4. Votre récapitulatif <ProgressBar now={0} /></Col>
    //       </Row>
    //     </Col>
    //   </Row>
    //   <Row>
    //     <Col md="2">1 of 3</Col>
    //     <Col md="8">
    //       <Card>
    //         <Card.Body>
    //           <Card.Title>Quel est votre numéro d'entreprise ?</Card.Title>
    //           <Card.Text>
    //             With supporting text below as a natural lead-in to additional
    //             content.
    //           </Card.Text>
    //           <Button variant="primary">Go somewhere</Button>
    //         </Card.Body>
    //       </Card>
    //     </Col>
    //     <Col md="2">3 of 3</Col>
    //   </Row>
    // </Container>
  );
}
