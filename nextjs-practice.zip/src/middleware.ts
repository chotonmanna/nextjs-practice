import { NextRequest, NextResponse } from "next/server";

const protectedRoutes = [
  '/users/basic',
  '/users/address',
  '/users/login'
];

const authRoute = '/auth';

export function middleware(req: NextRequest) {
  const path = req.nextUrl.pathname;
  const isProtectedRoutes = checkIsProtectedRoutes(path);
  const token = req.cookies.get('authData')?.value;

  if (authRoute === path && token) {
    return NextResponse.redirect(new URL('/users', req.nextUrl));
  }

  if (isProtectedRoutes && !token) {
    return NextResponse.redirect(new URL('/auth', req.nextUrl));
  }

  return NextResponse.next();
}

const checkIsProtectedRoutes = (path: string): boolean => {
  let count = 0;

  protectedRoutes.forEach(route => {
    if (path.includes(route)) {
      count++;
    }
  });

  return !!(count > 0);
}

//Routes Middleware should not run on
export const config = {
  matcher: ['/((?!api|_next/static|_next/image|.*\\.png$).*)'],
}