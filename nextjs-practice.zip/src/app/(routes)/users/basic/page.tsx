'use client'

import { Radio, Textbox } from "@/app/shared/components/formik-fields";
import { withAuthGuard } from "@/app/shared/components/withAuthGuard";
import { useAppDispatch, useAppSelector } from "@/store";
import { userActions } from "@/store/users/userSlice";
import { Formik, Form, Field } from "formik";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import * as Yup from 'yup';

interface PropsType {
  id?: string;
  mode?: string;
}

const genderData = [{ label: 'Male', value: 'M' }, { label: 'Female', value: 'F' }];

const BasicDetailsPage = ({
  id,
  mode
}: {
  id?: string;
  mode?: string;
}) => {
  const router = useRouter();
  const dispatch = useAppDispatch();
  const { formData, list } = useAppSelector(state => state.user);
  const basicDetailsSchema = Yup.object().shape({
    firstName: Yup.string().required('Required'),
    lastName: Yup.string().required('Required'),
    email: Yup.string().email('Invalid email').required('Required'),
  });

  useEffect(() => {
    //console.log('call edit', id);
    if (id) {
      dispatch(userActions.getEditableData({ editId: id }));
    }
  }, [id, list.length])

  return (
    <div>
      <h2 className="form-page-title">Basic Details:</h2>
      <Formik
        enableReinitialize={true}
        initialValues={{
          firstName: formData?.firstName || '',
          lastName: formData?.lastName || '',
          email: formData?.email || '',
          mobile: formData?.mobile || '',
          dob: formData?.dob || '',
          gender: formData?.gender || ''
        }}
        validationSchema={basicDetailsSchema}
        onSubmit={(values, { resetForm, setSubmitting }) => {
          console.log(values);
          dispatch(userActions.updateFormData(values));
          let url = `/users/gallery`;
          if (id && mode) {
            url = `${url}/${id}/${mode}`;
          }
          setSubmitting(false);
          router.push(url);
        }}
      >
        {({ isSubmitting }) => (
          <Form className="form">

            <Textbox name="firstName" label="First Name" />
            <Textbox name="lastName" label="Last Name" />
            <Textbox name="email" label="Email Id" />
            <Textbox name="mobile" label="Mobile" />
            <Radio name="gender" options={genderData} />

            <div className="form-field">
              <label htmlFor="email">Date of birth</label>
              <Field id="text" name="dob" type="date" />
            </div>
            {JSON.stringify(isSubmitting)}
            <button className="btn-green" type="submit" disabled={isSubmitting}>{isSubmitting ? 'Saving....' : 'Save & Next'}</button>
          </Form>
        )}
      </Formik>
      {/* <button onClick={onClickAddUSer}>Add User</button>
      <Link href={'/users/address'}>Go to next</Link> */}
    </div>
  );
}

export default withAuthGuard(BasicDetailsPage);