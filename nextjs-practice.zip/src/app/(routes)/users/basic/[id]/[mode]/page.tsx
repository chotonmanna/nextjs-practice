import BasicDetailsPage from "../../page";

interface PropsType {
  params: Promise<{
    id: string;
    mode: string;
  }>;
}

export default async function BasicDetailsModePage({
  params
}: {
  params: Promise<{
    id: string;
    mode: string;
  }>;
}) {
  const { id, mode } = (await params);
  return (
    <>
      <h1>{mode} == {id}</h1>
      <BasicDetailsPage id={id} mode={mode} />
    </>
  );
}