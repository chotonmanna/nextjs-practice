import { redirect } from "next/navigation";

export default function UsersPage() { 
  redirect('/users/basic');  
}