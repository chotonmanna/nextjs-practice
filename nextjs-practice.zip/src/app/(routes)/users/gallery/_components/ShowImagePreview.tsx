import { useAppSelector } from "@/store";
import { memo, useMemo } from "react";
import Image from 'next/image'

const ShowImagePreview = () => {
  const { formData } = useAppSelector(state => state.user);

  const displayFiles = useMemo(() => {
    if (formData?.photos) {
      return Array.from(formData.photos).map(file => {
        if (typeof file !== 'string') {
          return URL.createObjectURL(file)
        }
        return file;
      });
    }

  }, [formData?.photos]);

  return (
    <div className="preview-container">
      {displayFiles?.map((img, i) =>
        <div key={i} className="preview">
          <Image src={img} alt={img} width={60} height={60} />
        </div>
      )}
    </div>
  );
};

export default memo(ShowImagePreview);