'use client'

import { AllowedFileType, FileUpload } from "@/app/shared/components/formik-fields";
import { withAuthGuard } from "@/app/shared/components/withAuthGuard";
import { useAppDispatch, useAppSelector } from "@/store";
import { userActions } from "@/store/users/userSlice";
import { Form, Formik } from "formik";
import { useRouter } from "next/navigation";
import ShowImagePreview from "./_components/ShowImagePreview";
import { useEffect } from "react";

const allowedTypes: AllowedFileType[] = ['jpg', 'png'];

const GalleryDetailsPage = ({
  id,
  mode
}: {
  id?: string;
  mode?: string;
}) => {
  const router = useRouter();
  const dispatch = useAppDispatch();
  const { formData, list } = useAppSelector(state => state.user);
  const onSelectFiles = (photos: FileList) => {
    dispatch(userActions.updateFormData({ photos }));
  }

  useEffect(() => {
    if (id) {
      dispatch(userActions.getEditableData({ editId: id }));
    }
  }, [id, list.length])

  return (
    <div>
      <h2 className="form-page-title">Gallery Details:</h2>
      <Formik
        enableReinitialize={true}
        initialValues={{
          photos: formData?.photos || []
        }}
        onSubmit={() => {
          let url = `/users/address`;
          if (id && mode) {
            url = `${url}/${id}/${mode}`;
          }
          router.push(url);
        }}
      >
        {({ }) => (
          <Form className="form" encType="multipart/form-data">
            {formData?.photos && <ShowImagePreview />}
            <FileUpload
              name="photos"
              label="Upload your photos"
              multiple={true}
              allowedTypes={allowedTypes}
              selectFiles={onSelectFiles}
            />
            <div>
              <button type="button" onClick={() => router.back()}>Go to back</button>
              <button type="submit">Save & Next</button>
            </div>
          </Form>
        )}
      </Formik>
    </div>
  );
}

export default withAuthGuard(GalleryDetailsPage);