import { redirect } from "next/navigation";

interface PropsType {
  params: Promise<{ id: string }>;
}

export default async function GalleryDetailsIdPage({
  params
}: {
  params: Promise<{ id: string }>;
}) {
  const id = (await params).id;
  redirect(`/users/gallery/${id}/view`);
}