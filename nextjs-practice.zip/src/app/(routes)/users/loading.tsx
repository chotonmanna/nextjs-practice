export default function LoadingUsers() {
  // You can add any UI inside Loading, including a Skeleton.
  return <h1>Loading component.....</h1>
}