'use client'

import { withAuthGuard } from "@/app/shared/components/withAuthGuard";
import { useAppDispatch, useAppSelector } from "@/store";
import { getAllList, submitFormData } from "@/store/users/userActions";
import { userActions } from "@/store/users/userSlice";
import { Formik, Form, Field, ErrorMessage } from "formik";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import * as Yup from 'yup';

interface PropsType {
  id?: string;
  mode?: string;
}

const LoginDetailsPage = (props: PropsType) => {
  const {id} = props;
  const router = useRouter();
  const dispatch = useAppDispatch();
  const { formData, list } = useAppSelector(state => state.user);
  const basicDetailsSchema = Yup.object().shape({
    username: Yup.string().required('Required'),
    password: Yup.string().required('Required')
  });

  useEffect(() => {
    if (id) {
      dispatch(userActions.getEditableData({ editId: id }));
    }
  }, [id, list.length])

  return (
    <div>
      <h2 className="form-page-title">Login Details:</h2>
      <Formik
        enableReinitialize={true}
        initialValues={{
          username: formData?.username || '',
          password: formData?.password || ''
        }}
        validationSchema={basicDetailsSchema}
        onSubmit={(values, { resetForm, setSubmitting }) => {
          //dispatch(userActions.updateFormData(values));
          //router.push('/users/address');
          const finalFormData = {...formData, ...values};
          console.log(finalFormData);
          dispatch(submitFormData(finalFormData)).unwrap()
          .then(resp => {
            //console.log('success', resp);
            setSubmitting(false);
            router.push('/users/basic');
          })
          .catch(err => {
            setSubmitting(false);
            //console.log('redirect', err);
          });
          //resetForm();
          
          //router.push('/users/basic');
        }}
      >
        {({ isSubmitting }) => (
          <Form className="form">
            <div className="form-field">
              <label htmlFor="username">Username</label>
              <Field type="text" id="username" name="username" />
              <ErrorMessage name="username" component="div" className="error-message" />
            </div>
            <div className="form-field">
              <label htmlFor="password">Password</label>
              <Field type="password" id="password" name="password" />
              <ErrorMessage name="username" component="div" className="error-message" />
            </div>
            <div>
              <button type="button" onClick={() => router.back()}>Go to back</button>
              <button type="submit" disabled={isSubmitting}>{isSubmitting ? 'Please wait....' : 'Submit'}</button>
            </div>
          </Form>
        )}
      </Formik>
      {/* <button onClick={onClickAddUSer}>Add User</button>
      <Link href={'/users/address'}>Go to next</Link> */}
    </div>
  );
}

export default withAuthGuard(LoginDetailsPage);