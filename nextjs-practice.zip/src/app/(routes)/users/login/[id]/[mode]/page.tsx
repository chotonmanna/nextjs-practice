import LoginDetailsPage from "../../page";

interface PropsType {
  params: Promise<{
    id: string;
    mode: string;
  }>;
}

export default async function LoginDetailsModePage({
  params
}: {
  params: Promise<{
    id: string;
    mode: string;
  }>;
}) {
  const { id, mode } = (await params)
  return (
    <>
      <h1>{mode} == {id}</h1>
      <LoginDetailsPage id={id} mode={mode} />
    </>
  );
}
