'use client';

import { useAppSelector } from "@/store";
import React, { Suspense } from "react";

interface PropsType {
  children: React.ReactNode,
  list: React.ReactNode
}

export default function UsersLayout({
  children,
  list
}: {
  children: React.ReactNode,
  list: React.ReactNode
}) {
  const { apiStatusMsg } = useAppSelector(state => state.user);
  return (
    <section>
      {apiStatusMsg && <div className="common-message">{apiStatusMsg}</div>}
      <div className="user-content">
        <div className="left-content">
          <h1>Manage User Information</h1>
          {children}</div>
        <div className="right-content">
          <h1>User List</h1>
          {list}
        </div>
      </div>
    </section>
  );
}
