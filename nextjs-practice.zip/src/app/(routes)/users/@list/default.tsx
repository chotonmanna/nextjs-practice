import UsersListPage from "./page";

export default function DefaultUsersListPage() {
  return (
    <UsersListPage />
  );
}