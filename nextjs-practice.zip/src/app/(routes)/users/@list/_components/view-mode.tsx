import AccessGuard from "@/app/shared/components/accessGuard";
import { TableRow, RowData } from "@/app/shared/components/table/table";
import { User } from "@/app/shared/models/user";
import { useAppDispatch, useAppSelector } from "@/store";
import { deleteUserData } from "@/store/users/userActions";
import Link from "next/link";
import { memo, useState } from "react";

export default memo(function DisplayViewMode({
  data,
  toggleViewMode
}: {
  data: User;
  toggleViewMode: () => void;
}) {
  //console.log('render DisplayViewMode');
  const dispatch = useAppDispatch();
  const { authData } = useAppSelector(state => state.auth);
  const [isUserDeleting, setUserDeleted] = useState(false);
  const onClickUserDelete = () => {
    if (confirm('Are you sure to delet this user ?')) {
      setUserDeleted(true);
      dispatch(deleteUserData(data.id)).unwrap().then(() => setUserDeleted(false))
    }
  }

  return (
    <TableRow>
      <RowData>{data.id}</RowData>
      <RowData>{`${data.firstName} ${data.lastName}`}</RowData>
      <RowData>{data.mobile}</RowData>
      <RowData>{data.email}</RowData>
      <RowData>{data.dob}</RowData>
      <RowData className="actions">
        {
          !isUserDeleting ? <>
            <AccessGuard action="general_edit"><Link href={`/users/basic/${data.id}/edit`}>Edit</Link></AccessGuard>
            <AccessGuard action="quick_edit"><button onClick={toggleViewMode}>Quick Edit</button></AccessGuard>
            {authData?.role === 'admin' && <button onClick={onClickUserDelete}>Delete</button>}
          </> : <strong>Deleting....</strong>
        }
      </RowData>
    </TableRow>
  );
})