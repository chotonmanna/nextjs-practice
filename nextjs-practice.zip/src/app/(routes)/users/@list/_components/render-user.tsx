import { User } from "@/app/shared/models/user";
import { memo, useCallback, useState } from "react";
import dynamic from "next/dynamic";
import DisplayEditMode from './edit-mode';
import DisplayViewMode from './view-mode';

//const DynamicDisplayViewMode = dynamic(() => import('./view-mode'), {ssr: false});
//const DynamicDisplayEditMode = dynamic(() => import('./edit-mode'), {ssr: false});

interface PropsType {
  data: User;
}

export default memo(function RenderUser({
  data, index
}: {
  data: User;
  index: number;
}) {
  //console.log('render RenderUser', index);
  const [isViewMode, setViewMode] = useState(true);
  const toggleViewMode = useCallback(() => {
    setViewMode(mode => !mode);
  }, []);

  return (
    isViewMode ?
      <DisplayViewMode data={data} toggleViewMode={toggleViewMode} /> :
      <DisplayEditMode data={data} index={index} toggleViewMode={toggleViewMode} />
  );
})
