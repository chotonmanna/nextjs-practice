
import { getAllUsers } from "@/app/shared/services/users";

interface PropsType {
  userId: string;
}

export default async function UsersDetailsPage({
  userId
}: {
  userId: string;
}) {
  const response = await getAllUsers(userId);
  
  return (
    <div>
      Hello
      {JSON.stringify(response[0])}
    </div>
  );
}