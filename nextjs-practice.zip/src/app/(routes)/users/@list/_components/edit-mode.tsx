import { User } from "@/app/shared/models/user";
import { useAppDispatch } from "@/store";
import { submitFormData } from "@/store/users/userActions";
import { Field, Formik } from "formik";
import { memo, useState } from "react";
import { TableRow, RowData } from "@/app/shared/components/table/table";
import { Textbox } from "@/app/shared/components/formik-fields";

export default memo(function DisplayEditMode({
  data,
  index,
  toggleViewMode
}: {
  data: User;
  index: number;
  toggleViewMode: () => void;
}) {
  //console.log('render DisplayEditMode');
  const [isSubmitting, setSubmitting] = useState(false);
  const dispatch = useAppDispatch();

  const onClickSaveData = (data: User) => {
    console.log(data);
    setSubmitting(true);
    dispatch(submitFormData(data)).unwrap()
      .then(resp => {
        toggleViewMode();
        setSubmitting(false);
      })
      .catch(err => {
        setSubmitting(false);
      });
  }

  const onClickCancel = () => {
    toggleViewMode();
  }

  return (
    <Formik
      enableReinitialize={true}
      initialValues={data}
      onSubmit={onClickSaveData}
    >
      {({ handleSubmit, handleReset }) => (
        <TableRow isEditableWithFormik={true} formikProps={{ onSubmit: handleSubmit, onReset: handleReset }}>
          <RowData>{data.id}</RowData>
          <RowData>
            <Textbox name="firstName" />
            <Textbox name="lastName" />
          </RowData>
          <RowData>
            <Textbox name="mobile" />
          </RowData>
          <RowData>
            <Textbox name="email" />
          </RowData>
          <RowData>
            <Field id="text" name="dob" type="date" />
          </RowData>
          <RowData className="actions">
            <button disabled={isSubmitting} type="submit">
              {isSubmitting ? 'Saving...' : 'Save Data'}
            </button>
            <button type="reset">Reset Data</button>
            <button type="button" onClick={onClickCancel}>Cancel</button>
          </RowData>
        </TableRow>
      )}
    </Formik>
  )
})