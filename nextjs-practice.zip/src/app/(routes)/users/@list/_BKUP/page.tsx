
'use client'

import { withAuthGuard } from "@/app/shared/components/withAuthGuard";
import { User } from "@/app/shared/models/user";
import { useAppSelector, useAppDispatch } from "@/store";
import { getAllList } from "@/store/users/userActions";
import { Formik, Form, FieldArray, FormikState } from "formik";
import { createContext, useEffect, useMemo } from "react";
import dynamic from "next/dynamic";

const DynamicRenderUser = dynamic(() => import('./_components/render-user'));

interface UserListContextModel {
  resetForm: (nextState?: Partial<FormikState<{ users: User[]; }>> | undefined) => void;
}

export const UserListContext = createContext<UserListContextModel>(null!);

const UsersListPage = () => {
  //const response = await getAllUsers();
  const { list, loading } = useAppSelector(state => state.user);
  const { authData } = useAppSelector(state => state.auth);
  const dispatch = useAppDispatch();
  useEffect(() => {
    dispatch(getAllList());
  }, []);

  const filteredList = useMemo(() => {
    if (authData?.role === 'user') {
      return list.filter(u => u.id === authData.userid);
    } else {
      return list;
    }
  }, [authData?.role, list]);

  const initialValues = useMemo(() => {
    return {
      users: filteredList.map(u => ({
        id: u.id,
        firstName: u.firstName,
        lastName: u.lastName,
        mobile: u.mobile,
        email: u.email,
        dob: u.dob
      } as User))
    }
  }, [filteredList]);

  if (loading) {
    return <h2>Loading list from api......</h2>
  }

  // if (error) {
  //   return <h2>Error.....</h2>
  // }
  return filteredList?.length && (
    <div>
      <h1>{/*response[0].firstName*/}</h1>
      {/* <Suspense fallback={<LoadingUsers />}>
        <UsersDetailsPage userId={'1234455'} />
      </Suspense> */}

      <Formik
        enableReinitialize={true}
        initialValues={initialValues}
        onSubmit={() => { }}>
        {({ values, resetForm }) => (
          <Form>

            <FieldArray name="users">
              {() => (
                <table width={'100%'} cellPadding={4} cellSpacing={4}>
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Mobile</th>
                      <th>Email</th>
                      <th>DOB</th>
                      <th>ACTIONS</th>
                    </tr>
                  </thead>
                  <tbody>
                    <UserListContext.Provider value={{ resetForm }}>
                      {values.users.length > 0 &&
                        values.users.map((data, index) => <DynamicRenderUser data={data} index={index} key={index} />)
                      }
                    </UserListContext.Provider>
                  </tbody>
                </table>
              )}
            </FieldArray>
          </Form>
        )}
      </Formik>
    </div>
  );
}

export default withAuthGuard(UsersListPage);