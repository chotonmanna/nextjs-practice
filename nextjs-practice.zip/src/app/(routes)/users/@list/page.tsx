
'use client'

import { withAuthGuard } from "@/app/shared/components/withAuthGuard";
import { User } from "@/app/shared/models/user";
import { useAppSelector, useAppDispatch } from "@/store";
import { getAllList } from "@/store/users/userActions";
import { useEffect, useMemo } from "react";
import dynamic from "next/dynamic";
import { TableData, TableHeader, HeaderData, TableBody, TablePaginator, TableContainer } from "@/app/shared/components/table";

const DynamicRenderUser = dynamic(() => import('./_components/render-user'), {ssr: false});

// interface UserListContextModel {
//   resetForm: (nextState?: Partial<FormikState<{ users: User[]; }>> | undefined) => void;
// }

//export const UserListContext = createContext<UserListContextModel>(null!);

const UsersListPage = () => {
  //const response = await getAllUsers();
  const { list, loading } = useAppSelector(state => state.user);
  const { authData } = useAppSelector(state => state.auth);
  const dispatch = useAppDispatch();
  useEffect(() => {
    dispatch(getAllList());
  }, []);

  const filteredList = useMemo(() => {
    if (authData?.role === 'user') {
      return list.filter(u => u.id === authData.userid);
    } else {
      return list;
    }
  }, [authData?.role, list]);

  // const initialValues = useMemo(() => {
  //   return {
  //     users: filteredList.map(u => ({
  //       id: u.id,
  //       firstName: u.firstName,
  //       lastName: u.lastName,
  //       mobile: u.mobile,
  //       email: u.email,
  //       dob: u.dob
  //     } as User))
  //   }
  // }, [filteredList]);

  if (loading) {
    return <h2>Loading list from api......</h2>
  }

  // if (error) {
  //   return <h2>Error.....</h2>
  // }
  return filteredList?.length && (
    <div>
      <h1>{/*response[0].firstName*/}</h1>
      {/* <Suspense fallback={<LoadingUsers />}>
        <UsersDetailsPage userId={'1234455'} />
      </Suspense> */}

      <TableContainer
        data={filteredList}
        filter="columns"
        filteredColumns={['firstName', 'mobile', 'email']}
      >
        <TableData >
          <TableHeader>
            <HeaderData name="id">ID</HeaderData>
            <HeaderData name="firstName">Name</HeaderData>
            <HeaderData name="mobile">Mobile</HeaderData>
            <HeaderData name="email">Email</HeaderData>
            <HeaderData name="dob">DOB</HeaderData>
            <HeaderData>ACTIONS</HeaderData>
          </TableHeader>
          <TableBody>
            {(row, index) => <DynamicRenderUser data={row} index={filteredList.findIndex(d => d.id === row.id)} />}
          </TableBody>

        </TableData>

        <TablePaginator />
      </TableContainer>
    </div>
  );
}

export default withAuthGuard(UsersListPage);