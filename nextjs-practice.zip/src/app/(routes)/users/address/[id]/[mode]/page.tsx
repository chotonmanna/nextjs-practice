import AddressDetailsPage from "../../page";

interface PropsType {
  params: Promise<{
    id: string;
    mode: string;
  }>;
}

export default async function AddressDetailsModePage({
  params
}: {
  params: Promise<{
    id: string;
    mode: string;
  }>;
}) {
  const { id, mode } = (await params)
  return (
    <>
      <h1>{mode} == {id}</h1>
      <AddressDetailsPage id={id} mode={mode} />
    </>
  );
}
