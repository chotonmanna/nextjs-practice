import { redirect } from "next/navigation";

interface PropsType {
  params: Promise<{ id: string }>;
}

export default async function AddressDetailsIdPage({
  params
}: {
  params: Promise<{ id: string }>;
}) {
  const id = (await params).id;
  redirect(`/users/address/${id}/view`);
}