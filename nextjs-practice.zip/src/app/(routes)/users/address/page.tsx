"use client";

import { Textbox } from "@/app/shared/components/formik-fields";
import { withAuthGuard } from "@/app/shared/components/withAuthGuard";
import { useAppDispatch, useAppSelector } from "@/store";
import { userActions } from "@/store/users/userSlice";
import { Formik, Form, Field } from "formik";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

// interface PropsType {
//   id?: string;
//   mode?: string;
// }

const AddressDetailsPage = ({ id, mode }: {
  id?: string;
  mode?: string;
}) => {
  const router = useRouter();
  const dispatch = useAppDispatch();
  const { formData, list } = useAppSelector(state => state.user);

  useEffect(() => {
    if (id) {
      dispatch(userActions.getEditableData({ editId: id }));
    }
  }, [id, list.length])

  return (
    <>
      <h2 className="form-page-title">Address Details:</h2>
      <Formik
        enableReinitialize={true}
        initialValues={{
          zipcode: formData?.zipcode || '',
          land: formData?.land || '',
          houseNumber: formData?.houseNumber || '',
          city: formData?.city || '',
          state: formData?.state || '',
          country: formData?.country || ''
        }}
        onSubmit={(values, { resetForm, setSubmitting }) => {
          dispatch(userActions.updateFormData(values));
          let url = `/users/login`;
          if (id && mode) {
            url = `${url}/${id}/${mode}`;
          }
          router.push(url);
        }}
      >
        {({ isSubmitting }) => (
          <Form className="form">
            <Textbox name="houseNumber" label="House Number" />
            <Textbox name="land" label="Landmark" />
            <Textbox name="city" label="City" />
            <Textbox name="zipcode" label="Zipcode" />
            <Textbox name="state" label="State" />
            <Textbox name="country" label="Country" />

            <div>
              <button type="button" onClick={() => router.back()}>Go to back</button>
              <button type="submit">Save & Next</button>
            </div>
          </Form>
        )}
      </Formik>
      {/* <button onClick={onClickAddUSer}>Add User</button>
      <Link href={'/users/address'}>Go to next</Link> */}
    </>
  );
}

export default withAuthGuard(AddressDetailsPage);