'use client'

import { withAuthGuard } from "@/app/shared/components/withAuthGuard"
import { UserList } from "../(admin)/manage-access/_components/userlist";
import { useCallback, useEffect, useState } from "react";
import { ShowWishlistData } from "./_components/show-data";
import { useAppDispatch, useAppSelector } from "@/store";
import { wishlistActions, wishlistTypes } from "@/store/wishlist/wishlistSlice";
import { getAllWishlistData, getWishlistData } from "@/store/wishlist/wishlistActions";

const WishlistPage = () => {
  const dispatch = useAppDispatch();
  const { currentLoadingIndex, data } = useAppSelector(state => state.wishlist);
  const [userId, setUserId] = useState<string>('');
  const onChangeUserId = useCallback((userId: string) => {
    setUserId(userId);
  }, []);

  // useEffect(() => {
  //   (userId && currentLoadingIndex > -1) && triggerWishlistData();
  // }, [currentLoadingIndex, userId]);

  useEffect(() => {
    userId && dispatch(getAllWishlistData(userId))
  }, [userId]);

  const triggerWishlistData = () => {
    dispatch(wishlistActions.initiateLoad({ wishlistType: wishlistTypes[currentLoadingIndex] }));
    dispatch(getWishlistData({ type: wishlistTypes[currentLoadingIndex], userId }));
  }

  const onClickGetData = () => {
    dispatch(wishlistActions.resetWishlist());
  }

  return (
    <div>
      <h1>My Wishlist</h1>
      <div className="user-content">
        <div className="left-content">
          <UserList onChangeUserId={onChangeUserId} />
          <button type="button" onClick={onClickGetData} disabled={!userId}>Get data one by one</button>
        </div>
        <div className="right-content wishlist-container">
          {data.map((wishlistData, i) => <ShowWishlistData key={i} data={wishlistData} />)}
        </div>
      </div>
    </div>
  );
}

export default withAuthGuard(WishlistPage);