import { WishlistData } from "@/store/wishlist/wishlistSlice";
import { memo } from "react";

export const ShowWishlistData = memo(({ data }: {
  data: WishlistData;
}) => {
  return (
    <div className="wishlist-data">
      <h2>{data.type}</h2>
      {data.status === 0 && <strong>Loading.....</strong>}
      {data.status === 1 && <strong>Unable to load data</strong>}
      {data.status === 2 &&
        data.values?.length === 0 ? <span>No records Available</span> :
        data.values?.map((val, i) => <span key={i}>{val}</span>)
      }
    </div>
  );
})