'use client';

import { useAppDispatch, useAppSelector } from "@/store";
import { authLogin } from "@/store/auth/authActions";
import { Formik, Form, Field, ErrorMessage } from "formik";
import { useRouter } from "next/navigation";
//import router from "next/router";
import * as Yup from 'yup';

export default function AuthPage() {
  const dispatch = useAppDispatch();
  const { loading, error } = useAppSelector(state => state.auth);
  const router = useRouter();
  const basicDetailsSchema = Yup.object().shape({
    username: Yup.string().required('Required'),
    password: Yup.string().required('Required')
  });

  return (
    <div className="mx-auto my-0 w-96">
      <h2 className="text-base font-medium underline text-blue-600">Please login:</h2>
      {error && <strong className="text-red-800">{error}</strong>}
      <Formik
        validationSchema={basicDetailsSchema}
        initialValues={{ username: '', password: '' }}
        onSubmit={(values, { resetForm, setSubmitting }) => {
          dispatch(authLogin(values))
            .unwrap()
            .then(() => router.push('/'))
            .finally(() => setSubmitting(loading));
        }}
      >
        {({ isSubmitting }) => (
          <Form className="flex-col">
            <div className="flex-col">
              <label htmlFor="username">Username</label>
              <Field type="text" id="username" name="username" />
              <ErrorMessage name="username" component="div" className="text-red-600 font-semibold text-sm" />
            </div>
            <div className="flex-col">
              <label htmlFor="password">Password</label>
              <Field type="password" id="password" name="password" />
              <ErrorMessage name="password" component="div" className="text-red-600 font-semibold text-sm" />
            </div>
            <div>
              {/* <button type="button" onClick={() => router.back()}>Go to back</button> */}
              <button type="submit" disabled={isSubmitting}
              className="btn-blue">{isSubmitting ? 'Please wait....' : 'Login'}</button>
            </div>
          </Form>
        )}
      </Formik>
    </div>
  );
}