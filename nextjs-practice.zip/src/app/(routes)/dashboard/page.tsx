//import { redirect } from "next/navigation";

export default function DashboardPage() {
  return (
    <div>
      Dashboard Page
    </div>
  );
  //redirect('/users/basic');  
}