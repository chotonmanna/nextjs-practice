//import { redirect } from "next/navigation";

export default function DashboardArchivePage() {
  return (
    <div>
      DashboardArchive Page
    </div>
  );
  //redirect('/users/basic');  
}