import React from "react";

interface PropsType {
  children: React.ReactNode,
  slota: React.ReactNode
}

export default function DashboardLayout({
  children,
  slota
}: {
  children: React.ReactNode,
  slota: React.ReactNode
}) {
  return (
    <section>
      <div>{children}</div>
      <div>{slota}</div>
    </section>
  );
}