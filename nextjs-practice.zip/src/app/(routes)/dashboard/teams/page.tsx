//import { redirect } from "next/navigation";

export default function DashboardTeamsPage() {
  return (
    <div>
      DashboardTeams Page
    </div>
  );
  //redirect('/users/basic');  
}