//import { redirect } from "next/navigation";

export default function SlotAPage() {
  return (
    <div>
      Slot A Page
    </div>
  );
  //redirect('/users/basic');  
}