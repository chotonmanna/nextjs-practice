//import { redirect } from "next/navigation";
import SlotAPage from "./page";

export default function DefaultSlotAPage() {
  return (
    <SlotAPage />
  );
  //redirect('/users/basic');  
}