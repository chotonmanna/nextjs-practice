"use client";
import { withAdminGuard } from "@/app/shared/components/withAdminGuard";
import { useAppDispatch, useAppSelector } from "@/store";
import { getAccessData, saveAccessData } from "@/store/access/accessAction";
import { useState, useMemo, ChangeEvent, useCallback } from "react";
import listoffields from "./_data/listoffields.json";
import DisplayApiResponse from '@/app/shared/components/api-response';
import { accessActions } from "@/store/access/accessSlice";
import { UserList } from "./_components/userlist";

const ManageUserAccess = () => {
  const dispatch = useAppDispatch();
  const { apiStatusMsg, accessData, listOfResetActions } = useAppSelector(state => state.access);
  const [userId, setUserId] = useState<string>('');

  const onChangeUserId = useCallback((userId: string) => {
    setUserId(userId);
    if (userId) {
      dispatch(getAccessData(userId));
    }
  }, []);

  const isCheckedAction = (action: string): boolean => {
    return !!accessData?.filter(a => a.action === action).length;
  }

  const isCheckedActionField = (action: string, field: string): boolean => {
    return !!(accessData?.find(a => a.action === action)?.fields.filter(f => f === field))?.length;
  }

  const onClickSaveData = () => {
    dispatch(saveAccessData({ accessData, userId }));
  }

  const isPending = useMemo(() => apiStatusMsg.type === 'pending', [apiStatusMsg.type]);

  return (
    <div>
      <h1>Manage User Access</h1>
      <DisplayApiResponse data={apiStatusMsg} />

      <div className="user-content">

        <div className="left-content">
          <UserList onChangeUserId={onChangeUserId} />
        </div>

        {userId &&
          <div className="right-content permission-content">
            <h2>Manage Permissions</h2>
            {listoffields.map((obj, i) =>
              <div className="permission" key={i}>
                <div className="permission-reset">
                  <label className="permission-actions">
                    <input type="checkbox" name="action" checked={isCheckedAction(obj.action)}
                      onChange={(e: ChangeEvent<HTMLInputElement>) => {
                        dispatch(accessActions.updateAccessData({ checked: e.target.checked, name: e.target.name, value: obj }));
                      }} />
                    {obj.action}
                  </label>
                  {listOfResetActions.includes(obj.action) &&
                    <a className="reset-action" onClick={() => dispatch(accessActions.resetAccessData(obj.action))}>Reset</a>
                  }
                </div>
                <div className="permission-fields">
                  {obj.fields.map((field, j) =>
                    <label key={j}>
                      <input type="checkbox" name="fields" checked={isCheckedActionField(obj.action, field)}
                        onChange={(e: ChangeEvent<HTMLInputElement>) => {
                          dispatch(accessActions.updateAccessData({ checked: e.target.checked, name: e.target.name, value: { action: obj.action, fields: [field] } }));
                        }} />
                      {field}
                    </label>
                  )}
                </div>
              </div>
            )}

            <button type="button" onClick={onClickSaveData} disabled={isPending || (listOfResetActions.length === 0)}>Save Data</button>
            {!!listOfResetActions.length && <button type="button" className="reset"
              onClick={() => dispatch(accessActions.resetAccessData())}>Reset Data</button>}
          </div>
        }
      </div>
    </div>
  );
}

export default withAdminGuard(ManageUserAccess);