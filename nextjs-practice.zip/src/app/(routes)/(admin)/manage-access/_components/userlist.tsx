import { useAppDispatch, useAppSelector } from "@/store";
import { getAllList } from "@/store/users/userActions";
import { useEffect, useMemo } from "react";

export const UserList = ({ onChangeUserId }: {
  onChangeUserId: (userId: string) => void
}) => {
  const { list } = useAppSelector(state => state.user);
  const dispatch = useAppDispatch();
  useEffect(() => { dispatch(getAllList()); }, []);

  const userSelectList = useMemo(() => list.map(user => (
    { label: `${user.firstName} ${user.lastName}`, value: user.id }
  )), [list]);

  return (
    <>
      <h2>Select User</h2>
      <select name="userId" onChange={(e) => onChangeUserId(e.target.value)}>
        <option value="">---- Select User ----</option>
        {userSelectList.map((user, i) => <option key={i} value={user.value}>{user.label}</option>)}
      </select>
    </>
  );
}