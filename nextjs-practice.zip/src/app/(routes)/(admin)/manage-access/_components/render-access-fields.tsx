// import { ErrorMessage, Field } from "formik";
// import listoffields from "../_data/listoffields.json";
// import { memo } from "react";

// export type AccessActionType = keyof typeof listoffields;

// export default memo(function RenderAccessFields({
//   action
// }: {
//   action: AccessActionType
// }) {
//   console.log('RenderAccessFields', action);
//   return (
//     <div className="form-field">
//       <label htmlFor="fields">Select fields</label>
//       <div role="group" className="checkbox-group">
//         {listoffields[action].map((field, index) =>
//           <label key={index}>
//             <Field type="checkbox" name="fields" value={field} /> {field}
//           </label>
//         )}
//         <ErrorMessage name="fields" component="div" className="error-message" />
//       </div>
//     </div>
//   );
// })