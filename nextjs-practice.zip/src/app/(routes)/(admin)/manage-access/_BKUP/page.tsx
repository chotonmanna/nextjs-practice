"use client";

import { Select, Radio, Checkbox } from "@/app/shared/components/formik-fields";
import { withAdminGuard } from "@/app/shared/components/withAdminGuard";
import { AccessActionType, AccessFormValuesPayload } from "@/app/shared/models/access";
import { useAppDispatch, useAppSelector } from "@/store";
import { getAccessData, saveAccessData } from "@/store/access/accessAction";
import { getAllList } from "@/store/users/userActions";
import { Formik, Form } from "formik";
import { useState, useMemo, useEffect, useCallback } from "react";
import listoffields from "./_data/listoffields.json";
import * as Yup from 'yup';
import DisplayApiResponse from '@/app/shared/components/api-response';

//const DynamicRenderAccessFields = dynamic(() => import('./_components/render-access-fields'));

const actionList = [
  { label: 'Edit', value: 'general_edit' },
  { label: 'Quick Edit', value: 'quick_edit' }
];

const ManageUserAccess = () => {
  const dispatch = useAppDispatch();
  const { list } = useAppSelector(state => state.user);
  const { apiStatusMsg } = useAppSelector(state => state.access);

  const [initialValues, setInitialValues] = useState<AccessFormValuesPayload>({} as AccessFormValuesPayload);

  const allFields = useMemo<Array<{ label: string; value: string; }>>(() => (
    initialValues.action && listoffields[initialValues.action].map(field => ({ label: field, value: field }))
  ), [initialValues.action]);

  useEffect(() => { dispatch(getAllList()); }, []);

  const userAccessSchema = Yup.object().shape({
    userId: Yup.string().required('Please select user'),
    action: Yup.string().required('Please select action'),
    fields: Yup.array().test('field_error', 'Please select at least one field', (values) => !!values?.length)
  });

  const userSelectList = useMemo(() => list.map(user => (
    { label: `${user.firstName} ${user.lastName}`, value: user.id }
  )), [list]);

  // const dt = useRef<FormikProps<{
  //   userId: string;
  //   action: AccessActionType;
  //   fields: string[];
  // }>>(null);

  // const setData = () => {
  //   setInitialValues(values => ({ ...values, fields: ['One', 'Three'] }));
  // }

  // const val = useMemo(() => {
  //   return `new action value ${dt.current?.values.action}`;
  // }, [dt.current?.values.action]);

  const onChangeUser = useCallback((userId: string) => {
    dispatch(getAccessData(userId)).unwrap().then(resp => setInitialValues(resp));
  }, []);
  const onChangeAction = useCallback((val: string) => {
    setInitialValues(prevVal => ({ ...prevVal, action: val as AccessActionType }))
  }, []);

  return (
    <div>
      <h1>Manage User Access</h1>
      <DisplayApiResponse data={apiStatusMsg} />
      <Formik
        enableReinitialize={true}
        initialValues={initialValues}
        validationSchema={userAccessSchema}
        onSubmit={(values, { setSubmitting }) => {
          dispatch(saveAccessData(values)).unwrap().finally(() => setSubmitting(false))
        }}
      >
        {({ values, isSubmitting }) => (
          <Form className="user-content">

            <div className="left-content">
              <h2>Select User</h2>
              <Select name="userId" onChange={onChangeUser} options={userSelectList} />
            </div>

            {values.userId &&
              <div className="right-content permission-content">

                <h2>Manage Permissions</h2>

                <Radio label="Select action" onChange={onChangeAction} name="action" options={actionList} />

                {allFields && <Checkbox label="Select Fields" name="fields" options={allFields} />}

                <button type="submit" disabled={isSubmitting}>{isSubmitting ? 'Please wait....' : 'Save Data'}</button>
              </div>
            }

          </Form>
        )}
      </Formik>
    </div>
  );
}

export default withAdminGuard(ManageUserAccess);