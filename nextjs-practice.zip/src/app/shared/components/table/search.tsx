import { useContext } from "react";
import { TableProvider } from "./table";

export const TableSearch = () => {
  const { dispatch } = useContext(TableProvider);

  return (
    <div className="table-search">
      <input type="text" placeholder="Type your keywords....."
        onChange={(e) => dispatch({ type: 'UPDATE_SEARCH_PARAMS', payload: { searchParams: e.target.value } })} />
    </div>
  );
}