export interface PaginationParams {
  activePage: number;
  showPerPage: number;
  limit: {
    start: number;
    end: number;
  }
}

export interface TableParamsStateType {
  pagination: PaginationParams;
  searchParams: string | null;
}

export interface TableParamsActionType {
  type: 'UPDATE_PAGINATION_PARAMS' | 'UPDATE_SEARCH_PARAMS';
  payload: {
    activePage?: number;
    showPerPage?: number;
    searchParams?: string;
  };
}

export const defaultRowsPerPageOptions = [5, 10, 15];

export type FilterType = 'global' | 'columns';