import Image from 'next/image';
import { useContext, useMemo, useState } from 'react';
import { TableProvider } from './table';
import { Form, Formik } from 'formik';
import { Checkbox } from '../formik-fields';

interface OptionValue {
  label: string;
  value: string;
}

export const ColumnFilter = ({ name }: {
  name?: string;
}) => {
  const { mainData } = useContext(TableProvider);
  const [showFilterBox, setToggleFilterBox] = useState(false);
  const [searchText, setSearchText] = useState<string>('');

  const list = useMemo<OptionValue[]>(() => mainData.map((row: any) => ({ label: row[name!], value: row[name!] })), [mainData]);

  const displayList = useMemo(() => {
    return list.filter((obj: OptionValue) => searchText ? obj?.value.toLowerCase().includes(searchText.toLowerCase()) : true)
  }, [list, searchText]);

  return (
    <div className="filter-container">
      <a onClick={() => setToggleFilterBox(val => !val)}>
        <Image src="/filter.png" width={16} height={16}
          alt={`Filter with ${name}`} title={`Filter with ${name}`} />
      </a>
      {showFilterBox && <div className="filter-box">
        <div className='search-text'>
          <input type='text' onChange={(e) => setSearchText(e.target.value)} placeholder={`Search ${name}..`} />
        </div>
        <Formik
          enableReinitialize={true}
          initialValues={{ [name!]: {} }}
          onSubmit={(values) => {
            console.log(values[name!]);
          }}
        >
          {({ }) => (
            <Form style={{ width: '100%' }}>
              <div className='listof-texts'>
                <Checkbox name={name!} options={displayList} displayAs='column' />
              </div>
              <div className='action-btns'>
                <button type='button' onClick={() => setToggleFilterBox(val => !val)}>Cancel</button>
                <button type='submit'>Submit</button>
              </div>
            </Form>
          )}
        </Formik>
      </div>
      }
    </div>
  );
}