import { TableParamsStateType, TableParamsActionType, PaginationParams } from "./model";

export const reducer = (state: TableParamsStateType, action: TableParamsActionType) => {
  switch (action.type) {
    case "UPDATE_PAGINATION_PARAMS":
      if (action.payload) {
        const { activePage, showPerPage } = action.payload;

        state.pagination = { ...state.pagination, activePage } as PaginationParams;

        if (showPerPage) {
          state.pagination = { ...state.pagination, showPerPage } as PaginationParams;
        }

        const start = state.pagination.activePage * state.pagination.showPerPage;
        const end = start + state.pagination.showPerPage;

        state.pagination = { ...state.pagination, limit: { start, end } };

        state = { ...state, ...state.pagination };
      }

      return state;
    case "UPDATE_SEARCH_PARAMS":
      const { searchParams } = action.payload;
      const activePage = 0;
      const start = activePage * state.pagination.showPerPage;
      const end = start + state.pagination.showPerPage;
      state.pagination = { ...state.pagination, activePage, limit: { start, end } } as PaginationParams;
      state = { ...state, searchParams: searchParams || null, pagination: { ...state.pagination } };
      return state;
    default:
      return state;
  }
}
