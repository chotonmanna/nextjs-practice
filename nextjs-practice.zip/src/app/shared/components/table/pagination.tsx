import { ChangeEvent, useContext, useEffect } from "react";
import { TableProvider } from "./table";
import { defaultRowsPerPageOptions } from "./model";

export const TablePaginator = ({
  showPerPage = defaultRowsPerPageOptions[0],
  rowsPerPageOptions = defaultRowsPerPageOptions
}: {
  showPerPage?: number,
  rowsPerPageOptions?: number[]
}) => {
  const { activePage, totalPages, dispatch } = useContext(TableProvider);

  useEffect(() => {
    onTriggerPagination(0, showPerPage);
  }, []);

  const onClickNext = () => {
    const pageNo = activePage + 1;
    if (pageNo < totalPages.length) {
      onTriggerPagination(pageNo);
    }
  }

  const onClickPrev = () => {
    const pageNo = activePage - 1;
    if (pageNo >= 0) {
      onTriggerPagination(pageNo);
    }
  }

  const onTriggerPagination = (activePage: number, showPerPage: number | null = null) => {
    let payload: { activePage: number; showPerPage?: number } = { activePage };
    if (showPerPage) {
      payload = { ...payload, showPerPage };
    }
    dispatch({ type: 'UPDATE_PAGINATION_PARAMS', payload })
  }

  const onChangePageOptions = (e: ChangeEvent<HTMLSelectElement>) => {
    onTriggerPagination(0, Number(e.target.value));
  }

  return (
    <div className="table-pagination">
      <div>
        <select onChange={onChangePageOptions}>
          {rowsPerPageOptions.map((val, i) => <option value={val} key={i}>{val}</option>)}
        </select>
      </div>
      <div>
        <a onClick={onClickPrev}>&laquo;</a>
        {totalPages.map(pageNo => <a className={activePage === pageNo ? 'active' : ''} key={pageNo}
          onClick={() => onTriggerPagination(pageNo)}>{pageNo + 1}</a>)}
        <a onClick={onClickNext}>&raquo;</a>
      </div>
    </div>
  );
}
