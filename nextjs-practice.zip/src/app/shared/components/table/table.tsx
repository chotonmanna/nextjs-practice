import { createContext, Fragment, memo, useContext, useMemo, useReducer } from "react";
import { reducer } from "./reducer";
import { defaultRowsPerPageOptions, FilterType, TableParamsStateType } from "./model";
import { ColumnFilter } from "./filter";
import { TableSearch } from "./search";

export const TableProvider = createContext<{
  totalPages: number[];
  mainData: any;
  displayData: any;
  activePage: number;
  dispatch: any;
  paginationLimit: { start: number; end: number; }
  filter?: FilterType,
  filteredColumns?: string[]
}>(null!);

export const TableContainer = memo(({ children, data, filter, filteredColumns = [] }: {
  children: JSX.Element | JSX.Element[],
  data: Array<string | number | boolean | Object>,
  filter?: FilterType,
  filteredColumns?: string[]
}): JSX.Element => {

  const initialState: TableParamsStateType = {
    pagination: {
      activePage: 0,
      showPerPage: defaultRowsPerPageOptions[0],
      limit: {
        start: 0,
        end: data.length
      }
    },
    searchParams: null
  }

  const [tableParams, dispatch] = useReducer(reducer, initialState);

  const searchResults = useMemo(() => {
    let results = data;
    if (tableParams?.searchParams) {
      results = data.filter((row: any) => {
        return Object.values(row).filter(v => typeof v === 'string').some((v: any) => v.toLowerCase().includes(tableParams.searchParams?.trim().toLowerCase()))
      });
    }
    return results;
  }, [tableParams.searchParams, data]);

  const totalPages = useMemo(() => {
    if (tableParams.pagination?.showPerPage) {
      return Array.from(Array(Math.ceil(searchResults.length / tableParams.pagination.showPerPage)).keys());
    }
    return [];
  }, [tableParams.pagination?.showPerPage, searchResults]);

  return (
    <div className="table-container">
      <TableProvider.Provider value={{
        mainData: data,
        displayData: searchResults, //.slice(tableParams.pagination?.limit.start, tableParams.pagination?.limit.end),
        totalPages,
        paginationLimit: tableParams.pagination?.limit,
        activePage: tableParams.pagination?.activePage!,
        dispatch,
        filter,
        filteredColumns
      }}>
        {filter === 'global' && <TableSearch />}
        {children}
      </TableProvider.Provider>
    </div>
  );
})


export const TableData = ({ children }: {
  children: JSX.Element[]
}): JSX.Element => {
  return (
    <div className="table-data">
      {children}
    </div>
  );
}

export const TableHeader = ({ children }: {
  children: JSX.Element[]
}) => {
  return (
    <div className="table-header">{children}</div>
  );
}

export const HeaderData = ({ children, name }: {
  children: string, name?: string;
}) => {
  const { filter, filteredColumns } = useContext(TableProvider);
  return (
    <div className="header-data">
      <div className="header-content">
        {children}
        {(filter === 'columns' && filteredColumns?.includes(name!)) && <ColumnFilter name={name} />}
      </div>
    </div>
  );
}

export const TableBody = ({ children }: {
  children: (row: any, index: number) => JSX.Element
}) => {
  const { displayData, paginationLimit } = useContext(TableProvider);
  return (
    <div className="table-body">
      {displayData.slice(paginationLimit.start, paginationLimit.end).map((row: any, i: number) =>
        <Fragment key={i}>{children(row, i)}</Fragment>
      )}
    </div>
  );
}

export const TableRow = ({ children, isEditableWithFormik = false, formikProps }: {
  children: JSX.Element[] | JSX.Element;
  isEditableWithFormik?: boolean;
  formikProps?: { onReset: () => void, onSubmit: () => void }
}) => {
  return (
    isEditableWithFormik ?
      <form {...formikProps} className="table-row">{children}</form> :
      <div className="table-row">{children}</div>
  );
}

export const RowData = ({ children, className }: {
  children: any; className?: string;
}) => {
  return (
    <div className="row-data">{children}</div>
  );
}

