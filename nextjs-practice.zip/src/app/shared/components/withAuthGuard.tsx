import { useAppSelector } from "@/store"
import { redirect } from "next/navigation";
import { useEffect } from "react";

export const withAuthGuard = (AuthProtectedComponent: any) => {
  return (props: any) => {
    const authData = useAppSelector(state => state.auth.authData);

    useEffect(() => {
      if (!authData) {
        redirect('/auth');
      }
    }, []);

    if (!authData) {
      return null;
    }

    return <AuthProtectedComponent {...props} />
  }
}