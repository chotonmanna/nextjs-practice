import { useAppSelector } from "@/store";
import { memo } from "react";

export default memo(function AccessGuard({ action, field, children }: {
  action: string;
  field?: string;
  children: React.ReactNode
}) {
  //console.log('render AccessGuard', action);
  const { authData } = useAppSelector(state => state.auth);

  if (authData?.role === 'admin') {
    return <>{children}</>
  }

  const hasAccess = !!(authData?.access.filter(accs => {
    if (accs.action === action) {
      if (field) {
        return accs.fields?.includes(field);
      }

      return true;
    }

    return false;
  }).length);
  return (
    <>
      {hasAccess && children}
    </>
  );
})