import { memo } from "react"
import { ApiStatusModel } from "../models/access";

const DisplayApiResponse = ({ data }: {
  data: ApiStatusModel
}) => {
  console.log('render DisplayApiResponse');
  return (
    <div className={data.type}>
      <h2>{data.msg}</h2>
    </div>
  );
}

export default memo(DisplayApiResponse);