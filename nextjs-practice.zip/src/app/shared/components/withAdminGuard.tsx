import { useAppSelector } from "@/store"
import { redirect } from "next/navigation";
import { useEffect } from "react";

export const withAdminGuard = (AdminProtectedComponent: any) => {
  return (props: any) => {
    const { authData } = useAppSelector(state => state.auth);

    useEffect(() => {
      if (authData?.role !== 'admin') {
        redirect('/');
      }
    }, []);

    if (authData?.role !== 'admin') {
      return null;
    }

    return <AdminProtectedComponent {...props} />
  }
}