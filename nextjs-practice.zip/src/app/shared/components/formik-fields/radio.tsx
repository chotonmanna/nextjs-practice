import { Field } from "formik";
import { memo } from "react";

interface PropsType {
  name: string;
  options: Array<{ label: string; value: string; }>;
  label?: string;
  errorComponent?: string;
  errorClassName?: string;
  onChange?: (val: string) => void;
}

export const Radio = memo(({
  name, label, errorComponent = 'div', errorClassName = 'error-message', options, onChange
}: PropsType) => {
  console.log('render Radio', name);
  return (
    <div className="form-field">
      {label && <label htmlFor={name}>{label}</label>}
      <div className="radio-groups">
        {options.map((opt, i) => (
          <label key={i}>
            <Field type="radio" onClick={() => onChange && onChange(opt.value)} name={name} value={opt.value} /> {opt.label}
          </label>
        ))}
      </div>
    </div>
  );
});