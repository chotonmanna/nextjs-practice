import { Field, ErrorMessage } from "formik";
import { memo } from "react";

interface PropsType {
  name: string;
  id?: string;
  options: Array<{ label: string; value: string; }>;
  label?: string;
  errorComponent?: string;
  errorClassName?: string;
  displayAs?: 'row' | 'column' | 'wrap';
}

export const Checkbox = memo(({
  id, name, label, errorComponent = 'div', errorClassName = 'error-message', options,
  displayAs = 'wrap'
}: PropsType) => {
  console.log('render Checkbox');
  return (
    <div className="form-field">
      {label && <label htmlFor="fields">{label}</label>}
      <div role="group" className={`checkbox-group display-as-${displayAs}`}>
        {options.map((opt, index) =>
          <label key={index}>
            <Field type="checkbox" name={name} value={opt.value} /> {opt.label}
          </label>
        )}
        <ErrorMessage name={name} component={errorComponent} className={errorClassName} />
      </div>
    </div>
  );
})