import { Field, ErrorMessage, FieldProps } from "formik";
import { memo, useState } from "react";

export type AllowedFileType = 'jpg' | 'png' | 'gif' | 'doc' | 'pdf';

interface PropsType {
  name: string;
  id?: string;
  label?: string;
  errorComponent?: string;
  errorClassName?: string;
  multiple?: boolean;
  allowedTypes?: AllowedFileType[];
  allowedSize?: number; // in KB
  selectFiles?: (files: FileList) => void;
}

export const FileUpload = memo(({
  id, name, label, errorComponent = 'div', errorClassName = 'error-message', multiple = false, allowedSize,
  allowedTypes, selectFiles
}: PropsType) => {
  console.log('render FileUpload', name);

  const checkAllowedTypes = (files: FileList) => {
    Array.from(files).forEach(file => {
      console.log(file.type, file.size, Math.floor(file.size) / 1024);
    });
  }

  return (
    <div className="form-field">
      {label && <label htmlFor={name}>{label}</label>}

      <Field name={name}>
        {({ field, form }: FieldProps) => (
          <input {...field} type="file" value={undefined} multiple={multiple}
            onChange={(e) => {
              const { files } = e.currentTarget;
              if (files?.length) {
                const dt = files[0];
                console.log(typeof files, typeof dt);
                //checkAllowedTypes(files);
                //setUploadedImages(files);
                selectFiles && selectFiles(files);
                form.setFieldValue(name, files);
              }
            }} />
        )}
      </Field>
      <ErrorMessage name={name} component={errorComponent} className={errorClassName} />
    </div>
  );
})