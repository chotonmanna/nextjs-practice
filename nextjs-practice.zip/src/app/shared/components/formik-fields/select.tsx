import { Field, ErrorMessage, FieldProps } from "formik";
import { memo } from "react";

interface PropsType {
  name: string;
  id?: string;
  options: Array<{ label: string; value: string; }>;
  label?: string;
  errorComponent?: string;
  errorClassName?: string;
  onChange?: (e: string) => void;
}

export const Select = memo(({
  id, name, label, errorComponent = 'div', errorClassName = 'error-message', options, onChange
}: PropsType) => {
  console.log('render Select');

  return (
    <div className="form-field">
      {label && <label htmlFor={name}>{label}</label>}
      <Field name={name}>
        {({ field, form }: FieldProps) => (
          <select {...field} onChange={(e) => {
            form.handleChange(e);
            onChange && onChange(e.target.value);
          }}>
            <option value="">---- Select Option ----</option>
            {options.map((opt, i) => <option key={i} value={opt.value}>{`${opt.label}`}</option>)}
          </select>
        )}
      </Field>
      <ErrorMessage name={name} component={errorComponent} className={errorClassName} />
    </div>
  );
})