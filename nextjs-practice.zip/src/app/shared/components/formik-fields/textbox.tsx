import { Field, ErrorMessage } from "formik";
import { memo } from "react";

export type TextboxType = 'text' | 'email' | 'password' | 'number';

interface PropsType {
  type?: TextboxType;
  name: string;
  id?: string;
  label?: string;
  errorComponent?: string;
  errorClassName?: string;
}

export const Textbox = memo(({
  type = 'text', id, name, label, errorComponent = 'div', errorClassName = 'error-message'
}: PropsType) => {
  //console.log('render Textbox', name);
  return (
    <div className="form-field">
      {label && <label htmlFor={name}>{label}</label>}
      <Field type={type} id={id || name} name={name} />
      <ErrorMessage name={name} component={errorComponent} className={errorClassName} />
    </div>
  );
})