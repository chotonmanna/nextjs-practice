import { memo } from "react";

const TestCounterb = ({ counter }: { counter: number }) => {
  console.log('render TestCounterb', counter);
  return (
    <div>
      <h2>TestCounterb</h2>
    </div>
  );
}

export default memo(TestCounterb);