'use client';

import { useAppDispatch, useAppSelector } from "@/store";
import { authActions } from "@/store/auth/authSlice";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { usePathname } from 'next/navigation';
import { useEffect } from "react";
import { AuthDataModel } from "../models/auth";
import { getCookieValue } from "../utils/cookies";
import { authLogout } from "@/store/auth/authActions";
// rounded-full border border-solid border-black/[.08] dark:border-white/[.145] transition-colors flex items-center justify-center hover:bg-[#f2f2f2] dark:hover:bg-[#1a1a1a] hover:border-transparent text-sm sm:text-base h-10 sm:h-12 px-4 sm:px-5 sm:min-w-44

const defaultClass = 'rounded-full border border-solid px-5 py-3 text-sm text-center hover:bg-gray-300 flex items-center justify-center';
const activeClass = 'bg-gray-300';

export default function HeaderLinks() {
  const { authData } = useAppSelector(state => state.auth);
  const pathname = usePathname();
  const dispatch = useAppDispatch();
  const router = useRouter();

  const logout = () => {
    dispatch(authLogout());
    router.push('/');
  }

  // flex gap-4 items-center flex-col sm:flex-row

  return (
    <div className="flex flex-row items-center gap-4">
      <Link
        className={`${defaultClass} ${pathname === '/' && activeClass}`}
        href="/"
      >
        Home
      </Link>
      <Link
        className={`${defaultClass} ${pathname.includes('/users') && activeClass}`}
        href={authData ? '/users' : '/auth'}
      >
        Go to Users
      </Link>
      {authData &&
        <Link
          className={`${defaultClass} ${pathname.includes('/wishlist') && activeClass}`}
          href='/wishlist'
        >
          Wishlist
        </Link>
      }
      {authData?.role === 'admin' &&
        <Link
          className={`${defaultClass} ${pathname.includes('/manage-access') && activeClass}`}
          href={'/manage-access'}
        >
          Manage Users Access
        </Link>
      }
      {
        authData ?
          <a
            className={defaultClass}
            onClick={logout}>
            Hello {authData?.name} || Logout
          </a> :
          <Link
            className={`${defaultClass} ${pathname.includes('/auth') && activeClass}`}
            href="/auth"
          >
            Login
          </Link>
      }

    </div>
  );
}