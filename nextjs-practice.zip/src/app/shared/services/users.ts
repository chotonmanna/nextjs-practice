import axios from "axios";
import { User } from "../models/user";

export function getAllUsers(userId: string | null = null) {
  let url = 'http://localhost:3001/user/list';
  if (userId) {
    url = `${url}?userId=${userId}`
  }
  return axios.get<{ data: User[] }>(url)
    .then(resp => {
      return Promise.resolve(resp.data.data);
    })
    .catch(err => {
      console.log(err.response.status, err.response.data)
      return Promise.reject(err.response.data?.msg);
      //throw new Error(err.response.data?.msg);
    });
  // try {
  //   const resp = await axios.get('http://localhost:3001/user/list');
  //   return new Promise(resolve => resolve(resp.data));
  // } catch (err) {
  //   console.log(123456, err)
  //   throw new Error('errrrrrrrrrrrrrrrrrrrrrr');
  // }

}