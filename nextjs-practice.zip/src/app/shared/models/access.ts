export interface AccessFormValuesPayload {
  action: string;
  fields: string[];
}

export type ApiStatusType = 'error' | 'success' | 'pending';

export interface ApiStatusModel {
  type: ApiStatusType;
  msg: string;
}

export interface AccessActionPayload {
  checked: boolean;
  name: string;
  value: AccessFormValuesPayload;
}