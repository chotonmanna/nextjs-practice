export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  mobile: string;
  dob: string;
  gender: 'M' | 'F';
  zipcode: string;
  land: string;
  houseNumber: string;
  city: string;
  state: string;
  country: string;
  password: string;
  username: string;
  photos: Array<string | File>;
}