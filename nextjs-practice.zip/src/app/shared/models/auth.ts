export interface AuthDataModel {
  userid: string;
  name: string;
  role: 'admin' | 'user';
  access: AccessType[] | 'all';
}

export interface AccessType {
  action: string;
  fields?: string[];
}