import { useAppDispatch, useAppSelector } from "@/store";
import { authActions } from "@/store/auth/authSlice";
import { useEffect } from "react";
import { getCookieValue } from "../utils/cookies";

export const useAuth = () => {
  // const { authData } = useAppSelector(state => state.auth);
  // const dispatch = useAppDispatch();
  // useEffect(() => {
  //   const authDataCookie = getCookieValue('authData');
  //   if (authDataCookie) {
  //     dispatch(authActions.initAuthData(authDataCookie));
  //   }
  // }, []);
}