
const APP_STORAGE_KEY = 'REDUX_STATE_DATA';

const whitelist = {
  user: ['formData', 'list'],
  wishlist: null
};

export const getAppState = () => {
  try {
    const serializedState = sessionStorage.getItem(APP_STORAGE_KEY);
    if (!serializedState) return undefined;
    return JSON.parse(serializedState);
  } catch (e) {
    return undefined;
  }
}

export const saveAppState = (stateData: any) => {
  let storageData = {};
  if (whitelist) {
    for (const reducer in whitelist) {
      const stateVariables = whitelist[reducer as keyof typeof whitelist],
        reducerValue = stateData[reducer as keyof typeof stateData];

      let sliceData = {};

      if (stateVariables !== null && stateVariables.length) {
        stateVariables.forEach(variable => {
          sliceData = { ...sliceData, [variable]: reducerValue[variable as keyof typeof reducerValue] };
        });
      } else {
        sliceData = reducerValue;
      }

      storageData = { ...storageData, [reducer]: sliceData };
    }
  } else {
    storageData = stateData;
  }

  sessionStorage.setItem(APP_STORAGE_KEY, JSON.stringify(storageData));
}