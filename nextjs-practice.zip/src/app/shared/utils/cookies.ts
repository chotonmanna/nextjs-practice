import * as Cookies from 'cookies-js';

export const getCookieValue = (key: string) => {
  try {
    const serializedState = Cookies.get(key);
    if (!serializedState) return null;
    return JSON.parse(serializedState);
  } catch (error) {
    return null;
  }
}

export const setCookieValue = (key: string, value: string, options: CookieOptions = { secure: false, expires: 900 }) => {
  Cookies.set(key, value, options);
}

export const removeCookieValue = (key: string) => {
  Cookies.expire(key);
}