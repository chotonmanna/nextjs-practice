'use client';

import { Fragment, memo, useEffect, useState } from "react";

import TestCounterb from './shared/components/test';
import dynamic from "next/dynamic";

//const DynamicTestCounterb = dynamic(() => import('./shared/components/test'));

export default function RootPage() {
  const [countera, setCountera] = useState(0);
  const [counterb, setCounterb] = useState(0);

  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    // this forces a rerender
    setHydrated(true)
  }, [])

  if (!hydrated) {
    // this returns null on first render, so the client and server match
    return null
  }

  const checkCounter = () => {
    setCountera(c => c + 1);
  }

  const checkCounterb = () => {
    setCounterb(c => c + 1);
  }

  return (
    <div>
      <h2>Welcome Next.js app</h2>
      {/* <DynamicTestCounterb counter={counterb} />
      {countera}
      <button onClick={checkCounter}>CLICK HERE A</button>
      <button onClick={checkCounterb}>CLICK HERE B</button> */}
      {/* <TableData>
        <TableHead>

        </TableHead>
      <TableBody data={[
        { fname: 'Biswajit', lname: 'Manna' },
        { fname: 'Subhajit', lname: 'Manna' },
        { fname: 'Ashutosh', lname: 'Kumar' },
        { fname: 'Sayan', lname: 'Kundu' }
      ]}>
        {(dt, i) => (
          <TableRow>
            <RowData>{dt.fname}</RowData>
            <RowData>{dt.lname}</RowData>
          </TableRow>
        )}
      </TableBody>
      </TableData> */}
    </div>
  );
}

// export const TableRow = ({ children }: {
//   children: JSX.Element[]
// }) => {
//   return (
//     <div className="table-row">{children}</div>
//   );
// }

// export const RowData = ({ children }: {
//   children: any
// }) => {
//   return (
//     <div className="row-data">{children}</div>
//   );
// }

// export const TableBody = ({ children, data }: {
//   children: (row: { fname: string; lname: string; }, index: number) => JSX.Element,
//   data: Array<{ fname: string; lname: string; }>
// }) => {
//   return (
//     <div>TABLE BODY
//       {/* <Fragment>{children({ fname: 'Biswajit', lname: 'Manna' }, 1)}</Fragment>
//       <Fragment>{children({ fname: 'Subhajit', lname: 'Manna' }, 2)}</Fragment>
//       <Fragment>{children({ fname: 'Ashutosh', lname: 'Kumar' }, 2)}</Fragment> */}
//       {data.map((row: { fname: string; lname: string; }, i: number) => <Fragment key={i}>{children(row, i)}</Fragment>)}
//     </div>
//   );
// }


