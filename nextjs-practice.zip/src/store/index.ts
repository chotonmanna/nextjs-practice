'use client';

import { combineReducers, configureStore } from '@reduxjs/toolkit';
import { useDispatch, useSelector, useStore } from 'react-redux';
import { userReducer } from './users/userSlice';
import { authReducer } from './auth/authSlice';
import { accessReducer } from './access/accessSlice';
import { wishlistReducer } from './wishlist/wishlistSlice';
import { getAppState } from '@/app/shared/utils/storage';
//import { FLUSH, PAUSE, PERSIST, PURGE, REGISTER, REHYDRATE } from 'redux-persist';

export const makeStore = () => {
  return configureStore({
    reducer: combineReducers({
      user: userReducer,
      auth: authReducer,
      access: accessReducer,
      wishlist: wishlistReducer
    }),

    middleware: (getDefaultMiddleware) => getDefaultMiddleware({ serializableCheck: false }),
    preloadedState: getAppState(),
  })
};

// Infer the type of makeStore
export type AppStore = ReturnType<typeof makeStore>;
// Infer the `RootState` and `AppDispatch` types from the store itself
export type RootState = ReturnType<AppStore['getState']>;
export type AppDispatch = AppStore['dispatch'];

// Create store hooks
export const useAppDispatch = useDispatch.withTypes<AppDispatch>();
export const useAppSelector = useSelector.withTypes<RootState>();
export const useAppStore = useStore.withTypes<AppStore>();


