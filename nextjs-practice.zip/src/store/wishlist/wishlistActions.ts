import { createAsyncThunk } from "@reduxjs/toolkit";
import axios, { Axios, AxiosError } from "axios";
import { wishlistTypes } from "./wishlistSlice";

const asyncTask = async (userId: string, type: string, duration = 2000) => {
  try {
    const response = await axios.get(`http://localhost:3001/user/wishlist/${userId}/${type}/${duration}`);
  return response.data.data;
  } catch (error) {
    return [];
  }
  
}

export const getWishlistData = createAsyncThunk('wishlist/getdata', (
  payload: { userId: string; type: string; }, { rejectWithValue }) => {
  try {
    return asyncTask(payload.userId, payload.type);
  } catch (error) {
    return rejectWithValue((error as AxiosError)?.response?.data);
  }
});

export const getAllWishlistData = createAsyncThunk('wishlist/getalldata', async (
  userId: string, { rejectWithValue }) => {
  try {
    const durations = [3000, 5000, 4000, 3500, 2500, 1000];
    const allAsyncTasks = wishlistTypes.map((type, i) => asyncTask(userId, type, durations[i]));
    const response = await Promise.all(allAsyncTasks);
    return response;
  } catch (error) {
    return rejectWithValue((error as AxiosError)?.response?.data);
  }
});