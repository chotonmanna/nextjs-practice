import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { getAllWishlistData, getWishlistData } from "./wishlistActions";
export const wishlistTypes = ['bollywoodMovies', 'hollywoodMovies', 'tollywoodMovies', 'webSeries', 'singers', 'actors'];

export interface WishlistData {
  type: string;
  status: number;
  values?: string[];
}

const wishlistSlice = createSlice({
  name: 'wishlist',
  initialState: {
    currentLoadingIndex: -1,
    data: [] as WishlistData[]
  },
  reducers: {
    initiateLoad(state, action: PayloadAction<{ wishlistType: string }>) {
      state.data.push({ type: action.payload.wishlistType, status: -1 })
    },
    resetWishlist(state) {
      state.currentLoadingIndex = 0;
      state.data = [];
    }
  },
  extraReducers(builder) {
    builder.addCase(getWishlistData.pending, (state) => {
      state.data[state.currentLoadingIndex].status = 0;
    }),
      builder.addCase(getWishlistData.rejected, (state) => {
        state.data[state.currentLoadingIndex].status = 1;
      }),
      builder.addCase(getWishlistData.fulfilled, (state, action: PayloadAction<string[]>) => {
        let i = state.currentLoadingIndex;
        state.data[i].status = 2;
        state.data[i].values = action.payload;

        i++;
        if (i < wishlistTypes.length) {
          state.currentLoadingIndex = i;
        } else {
          state.currentLoadingIndex = -1; // Reset to initial value
        }
      })
    builder.addCase(getAllWishlistData.pending, (state, action) => {
      console.log('pending', action.payload);
    }),
    builder.addCase(getAllWishlistData.rejected, (state, action) => {
      console.log('rejected', action.payload);
    }),
    builder.addCase(getAllWishlistData.fulfilled, (state, action) => {
      console.log('fulfilled', action.payload);
    })
  },
});

export const wishlistActions = wishlistSlice.actions;
export const wishlistReducer = wishlistSlice.reducer;