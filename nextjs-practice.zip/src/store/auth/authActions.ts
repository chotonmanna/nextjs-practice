import { getCookieValue, removeCookieValue, setCookieValue } from "@/app/shared/utils/cookies";
import { createAsyncThunk } from "@reduxjs/toolkit";
import axios, { AxiosError } from "axios";

export interface LoginModel {
  username: string;
  password: string;
}

export const authLogin = createAsyncThunk('auth/login', async (data: LoginModel, thunkAPI) => {
  try {
    const response = await axios.post('http://localhost:3001/user/login', data);
    setCookieValue('authData', JSON.stringify(response.data.data));
    return response.data.data;
  } catch (error) {
    return thunkAPI.rejectWithValue((error as AxiosError)?.response?.data);
  }
});

export const authLogout = createAsyncThunk('auth/logout', async () => {
  removeCookieValue('authData');
});

