import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { authLogin, authLogout } from "./authActions";
import { ErrorType } from "../users/userSlice";

import { AuthDataModel } from "@/app/shared/models/auth";
import { getCookieValue } from "@/app/shared/utils/cookies";

interface InitialStateModel {
  loading: boolean;
  error: string;
  authData: AuthDataModel | null;
}

const initialState: InitialStateModel = {
  authData: getCookieValue('authData'),
  error: '',
  loading: false
}

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(authLogin.pending, (state) => {
      state.loading = true;
    }),
      builder.addCase(authLogin.fulfilled, (state, action: PayloadAction<AuthDataModel>) => {
        state.loading = false;
        state.authData = action.payload;
      }),
      builder.addCase(authLogin.rejected, (state, action) => {
        state.loading = false;
        state.error = (action.payload as ErrorType)?.msg;
      }),
      builder.addCase(authLogout.fulfilled, (state) => {
        state.authData = null;
      })
  }
});

export const authActions = authSlice.actions;
export const authReducer = authSlice.reducer;