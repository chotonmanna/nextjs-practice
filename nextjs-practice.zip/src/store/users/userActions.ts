import { User } from "@/app/shared/models/user";
import { createAsyncThunk, isRejectedWithValue } from "@reduxjs/toolkit";
import axios, { AxiosError } from "axios";
import { redirect } from 'next/navigation';
import { RootState } from "..";

export const getAllList = createAsyncThunk('users/getlist', async (_, { rejectWithValue }) => {
  try {
    const response = await axios.get(`http://localhost:3001/user/list`);
    return response.data;
  } catch (error) {
    return rejectWithValue((error as AxiosError)?.response?.data);
  }
}, {
  condition: (_, { getState }) => {
    const { user } = getState() as RootState;
    if (user.list.length) {
      return false;
    }

    return true;
  }
});

export const submitFormData = createAsyncThunk('users/submitdata', async (data: User, { rejectWithValue }) => {
  try {
    const formData = new FormData();
    for (let key in data) {
      const value = data[key as keyof User];
      if (typeof value === 'object') {
        Array.from(value).forEach(obj => {
          formData.append('photos', obj);
        });
      } else {
        formData.append(key, value);
      }
    }
    console.log(formData.entries());
    const response = await axios.post(`http://localhost:3001/user/registration`, formData, {
      headers: { "Content-Type": "multipart/form-data" }
    });
    //console.log('try');
    return response.data;
  } catch (error) {
    //console.log('catch', error);
    return rejectWithValue((error as AxiosError)?.response?.data);
  }
});

export const deleteUserData = createAsyncThunk('users/deletedata', async (id: string, { rejectWithValue }) => {
  try {
    const response = await axios.delete(`http://localhost:3001/user/delete/${id}`);
    //console.log('try');
    return response.data;
  } catch (error) {
    console.log('catch', error);
    return rejectWithValue((error as AxiosError)?.response?.data);
  }
});