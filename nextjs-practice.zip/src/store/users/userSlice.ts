'use client';

import { User } from "@/app/shared/models/user";
import { combineReducers, createSlice } from "@reduxjs/toolkit";
import { persistReducer } from 'redux-persist';
//import storageSession from 'redux-persist/lib/storage/session';
import createWebStorage from "redux-persist/lib/storage/createWebStorage";
import { deleteUserData, getAllList, submitFormData } from "./userActions";
import type { PayloadAction } from '@reduxjs/toolkit'
//import { getFromStorage, setToStorage } from "@/app/shared/utils/storage";

export interface ErrorType {
  msg: string;
}

const userSlice = createSlice({
  name: 'users',
  initialState: {
    formData: {} as User,
    list: [] as User[],
    loading: false,
    apiStatusMsg: null as string | null,
    //uploadedImages: [] as File[]
    //isDeleting: false
  },
  reducers: {
    updateList(state, action) {
      state.list = { ...state.list, ...action.payload };
      //setToStorage<User[]>('usersList', state.list);
    },
    updateFormData(state, action) {
      state.formData = { ...state.formData, ...action.payload };
      //console.log(action.payload, state.formData);
      //setToStorage<User>('usersFormData', state.formData);
    },
    getEditableData(state, action) {
      if (!Object.keys(state.formData).length) {
        console.log('getEditableData');
        state.formData = { ...state.formData, ...state.list.find(u => u.id === action.payload.editId) };
      }
    },
    // updateUploadImages(state, action: PayloadAction<{ photos: FileList }>) {
    //   state.uploadedImages = [...state.uploadedImages, ...action.payload.photos];
    // }
  },
  extraReducers: (builder) => {
    builder.addCase(getAllList.fulfilled, (state, action) => {
      state.loading = false;
      state.list = action.payload.data;
      //setToStorage<User[]>('usersList', state.list);
    }),
      builder.addCase(getAllList.pending, (state) => {
        state.loading = true;
      }),
      builder.addCase(getAllList.rejected, (state, action) => {
        console.log(action.payload);
        state.loading = false;
        state.apiStatusMsg = (action.payload as ErrorType)?.msg;
      }),
      // builder.addCase(submitFormData.pending, (state) => {
      //   state.isSubmitProcessing = true;
      // }),
      builder.addCase(submitFormData.fulfilled, (state, action) => {
        //state.isSubmitProcessing = false;
        state.formData = {} as User;
        state.list = action.payload.data;
        state.apiStatusMsg = 'New users data are updated';
        console.log('submitFormData.fulfilled', state.formData);
        //setToStorage<User[]>('usersList', state.list);
      }),
      builder.addCase(submitFormData.rejected, (state, action) => {
        //state.isSubmitProcessing = false;
        state.apiStatusMsg = (action.payload as ErrorType)?.msg;
        //console.log('submitFormData.rejected', action.payload);
      }),
      // builder.addCase(deleteUserData.pending, (state, action) => {
      //   state.isDeleting = true;
      // }),
      builder.addCase(deleteUserData.fulfilled, (state, action) => {
        //state.isDeleting = false;
        state.list = action.payload.data;
        state.apiStatusMsg = action.payload.msg;
      })
    // builder.addCase(deleteUserData.rejected, (state, action) => {
    //   state.isDeleting = false;
    // })
  }
});


// const createNoopStorage = () => {
//   return {
//     getItem() {
//       return Promise.resolve(null);
//     },
//     setItem(_key: any, value: any) {
//       return Promise.resolve(value);
//     },
//     removeItem() {
//       return Promise.resolve();
//     },
//   };
// };

// const storage = typeof window !== "undefined" ? createWebStorage("session") : createNoopStorage();

//export default storage;

// export const userActions = userSlice.actions;
// //export const userListReducer = userSlice.reducer;
// export const userReducer = persistReducer({
//   timeout: 200,
//   key: 'users-persist',
//   storage,
//   whitelist: ['formData', 'list']
// }, userSlice.reducer);

export const userActions = userSlice.actions;
export const userReducer = userSlice.reducer;