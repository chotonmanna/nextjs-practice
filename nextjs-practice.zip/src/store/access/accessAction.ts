import { AccessFormValuesPayload } from "@/app/shared/models/access";
import { createAsyncThunk } from "@reduxjs/toolkit";
import axios, { AxiosError } from "axios";

export const getAccessData = createAsyncThunk('access/getdata', async (userId: string, { rejectWithValue }) => {
  try {
    const response = await axios.get(`http://localhost:3001/access/getbyid/${userId}`);
    return response.data.data;
  } catch (error) {
    return rejectWithValue((error as AxiosError)?.response?.data);
  }
});

export const saveAccessData = createAsyncThunk('access/savedata', async (data: { accessData: AccessFormValuesPayload[]; userId: string }, { rejectWithValue }) => {
  try {
    const response = await axios.put(`http://localhost:3001/access/manage/${data.userId}`, data.accessData);
    return response.data.data;
  } catch (error) {
    return rejectWithValue((error as AxiosError)?.response?.data);
  }
});
