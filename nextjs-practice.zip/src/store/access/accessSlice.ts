import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { getAccessData, saveAccessData } from "./accessAction";
import { ErrorType } from "../users/userSlice";
import { AccessActionPayload, AccessFormValuesPayload, ApiStatusModel } from "@/app/shared/models/access";

const accessSlice = createSlice({
  name: 'manage-access',
  initialState: {
    apiStatusMsg: {} as ApiStatusModel,
    accessData: [] as AccessFormValuesPayload[],
    backupAccessData: [] as AccessFormValuesPayload[],
    listOfResetActions: [] as string[]
  },
  reducers: {
    updateAccessData(state, action: PayloadAction<AccessActionPayload>) {
      const { checked, value, name } = action.payload;
      if (checked) {
        const i = state.accessData.findIndex(a => a.action === value.action);
        if (i === -1) { // First time no records
          state.accessData = [...state.accessData, ...[value]];
        } else { // After first time
          state.accessData[i] = { ...state.accessData[i], fields: [...state.accessData[i].fields, ...value.fields] };
        }
      } else {
        const actionIndex = state.accessData.findIndex(p => p.action === value.action);

        if (name === 'fields') {
          const fieldsIndex = state.accessData[actionIndex].fields.findIndex(f => f === value.fields[0]);

          if (fieldsIndex > -1) {
            state.accessData[actionIndex].fields.splice(fieldsIndex, 1);
          }

          if (state.accessData[actionIndex].fields.length === 0) {
            state.accessData.splice(actionIndex, 1);
          }
        }

        if (name === 'action') {
          if (actionIndex > -1) {
            state.accessData.splice(actionIndex, 1);
          }
        }
      }

      // Check resetting action or not
      const data1 = state.accessData.find(p => p.action === value.action);
      const data2 = state.backupAccessData.find(p => p.action === value.action);
      let isResetting;
      if (typeof data1 === 'undefined' && typeof data2 === 'undefined') {
        isResetting = false;
      } else if (typeof data1?.fields === 'undefined' || typeof data2?.fields === 'undefined') {
        isResetting = true;
      } else {
        const f1 = JSON.parse(JSON.stringify(data1?.fields)), f2 = JSON.parse(JSON.stringify(data2?.fields));
        isResetting = JSON.stringify(f1.sort()) !== JSON.stringify(f2?.sort());
      }

      const i = state.listOfResetActions.findIndex(p => p === value.action);
      if (isResetting && i === -1) {
        state.listOfResetActions = [...state.listOfResetActions, value.action];
      } else if (!isResetting && i > -1) {
        state.listOfResetActions.splice(i, 1);
      }
    },
    resetAccessData(state, action: PayloadAction<string | undefined>) {
      if (action.payload) {
        const index1 = state.accessData.findIndex(p => p.action === action.payload);
        const index2 = state.backupAccessData.findIndex(p => p.action === action.payload);
        const index3 = state.listOfResetActions.findIndex(p => p === action.payload);

        if (index2 === -1) {
          state.accessData.splice(index1, 1);
        } else if (index1 === -1) {
          state.accessData = [...state.accessData, ...[state.backupAccessData[index2]]];
        } else {
          state.accessData[index1] = { ...state.backupAccessData[index2] };
        }
        state.listOfResetActions.splice(index3, 1);
      } else {
        state.accessData = [...state.backupAccessData];
        state.listOfResetActions = [];
      }
    }
  },
  extraReducers: (builder) => {
    builder.addCase(getAccessData.pending, (state) => {
      state.apiStatusMsg = { type: 'pending', msg: 'Fetching your access data. Please wait......' };
    }),
      builder.addCase(getAccessData.fulfilled, (state, action) => {
        state.apiStatusMsg = { type: 'success', msg: 'Access data is retrived successfully' };
        state.accessData = action.payload;
        state.backupAccessData = action.payload;
        state.listOfResetActions = [];
      }),
      builder.addCase(getAccessData.rejected, (state, action) => {
        state.apiStatusMsg = { msg: (action.payload as ErrorType)?.msg, type: 'error' };
      }),
      builder.addCase(saveAccessData.pending, (state) => {
        state.apiStatusMsg = { type: 'pending', msg: 'Saving your access data. Please wait......' };
      }),
      builder.addCase(saveAccessData.fulfilled, (state, action) => {
        state.listOfResetActions = [];
        state.accessData = action.payload;
        state.backupAccessData = action.payload;
        state.apiStatusMsg = { type: 'success', msg: 'Access data is saved successfully' };
      }),
      builder.addCase(saveAccessData.rejected, (state, action) => {
        state.apiStatusMsg = { msg: (action.payload as ErrorType)?.msg, type: 'error' };
      })
  },
});

export const accessActions = accessSlice.actions;
export const accessReducer = accessSlice.reducer;
