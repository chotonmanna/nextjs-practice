export interface MsgModel {
  type: "Q" | "A";
  msgText: string;
  status?: "0" | "1" | "2"; // 0 = Pending, 1 = Failed, 2 = Success
}
export default function MsgBox({ data }: Readonly<{ data: MsgModel }>) {
  const dir = data.type === "Q" ? "left" : "right";
  return (
    <div className={`msg ${dir}-msg`}>
      <div className={`msg-img msg-img-${data.type.toLowerCase()}`}>{data.type}</div>

      <div className="msg-bubble">
        <div className="msg-info">
          <div className={`msg-info-name msg-info-name-${data.type.toLowerCase()}`}>{data.type === "Q" ? 'Question' : 'Answer'}</div>
          {/* <div className="msg-info-time">12:45</div> */}
        </div>
        {data.type === "Q" && <div className="msg-text">{data.msgText}</div>}
        {data.type === "A" && (
          <div className="msg-text">
            {data.status === "0" && "........."}
            {data.status === "2" && <div dangerouslySetInnerHTML={{ __html: data.msgText }}></div>}
          </div>
        )}
      </div>
    </div>
  );
}
