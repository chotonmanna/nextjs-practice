"use client";

import { FormEvent, useEffect, useRef, useState } from "react";
import MsgBox, { MsgModel } from "./msg-box";
import { useSearchParams } from 'next/navigation';
import mockResponse from '../public/mockresponse.json';

const defaultQuestion = 'summarize the key points of the policy with a simplified explanation';

export default function Home() {
  const [msgText, setMsgText] = useState("");
  const [isFormDisabled, setIsFormDisabled] = useState(false);
  const [chatList, setChatList] = useState<MsgModel[]>([]);
  const divRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const searchParams = useSearchParams();

  useEffect(() => {
    handleOnTriggerAnswer(searchParams.get('question') ?? defaultQuestion);
  },[])

  useEffect(() => {
    if (!isFormDisabled) {
      inputRef.current?.focus();
    }
  }, [isFormDisabled])

  useEffect(() => {
    divRef?.current?.scrollTo({ top: divRef?.current?.scrollTop + 1000 ,behavior: "smooth"});
  }, [chatList[chatList.length - 1]?.msgText]);

  const handleOnSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();    
    handleOnTriggerAnswer(msgText);
    setMsgText("");
  };

  const handleOnTriggerAnswer = (msgText: string) => {
    setIsFormDisabled(true);
    setChatList((list) => [ ...list, { msgText, type: "Q" }, { msgText: "", type: "A", status: "0" }]);
    getAnswer(msgText).then(msgText => {
      setChatList((list) => {
        const lastIndex = list.length - 1
        list[lastIndex] = {...list[lastIndex], msgText, status: '2'};
        return list;
      });
      setIsFormDisabled(false);
    });
  }

  const getAnswer = (question: string): Promise<string> => {
    return new Promise((resolve, reject) => { 
      const i = Math.floor(Math.random() * 5);
      setTimeout(() => resolve(mockResponse[i].answer), 2800);
    });
  }
  console.log(searchParams.get('policyNumber'));
  return (
    searchParams.get('policyNumber') ?
    <section className="msger">
      <header className="msger-header">
        <div className="msger-header-title">KNOW YOUR POLICY : {searchParams.get('policyNumber')}</div>
        <div className="msger-header-options">
          <span>
            <i className="fas fa-cog"></i>
          </span>
        </div>
      </header>
      
      <main className="msger-chat" ref={divRef}>
        {chatList.map((data, i) => <MsgBox key={i} data={data} />)}
      </main>

      <form className="msger-inputarea" onSubmit={handleOnSubmit}>
        <input
          required
          disabled={isFormDisabled}
          type="text"
          className="msger-input"
          placeholder="Enter your message..."
          name="msgText"
          value={msgText}
          ref={inputRef}
          onChange={(e) => setMsgText(e.target.value)}
        />
        <button disabled={isFormDisabled} type="submit" className="msger-send-btn">
          Send
        </button>
      </form>
    </section> :
    <h2>No Policy Available</h2>
  );
}
